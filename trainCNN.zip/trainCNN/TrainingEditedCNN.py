import csv
import numpy as np
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv2D,Flatten,Dense,Activation,Dropout,MaxPooling2D
#from tensorflow.keras.activations import relu
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import train_test_split
#we will use images 26x34x1 (1 is for grayscale images)
height = 26
width = 34
dims = 1

def readCsv(path):

	with open(path,'r') as f:
		#read the scv file with the dictionary format 
		reader = csv.DictReader(f)      
		rows = list(reader)

	#imgs is a numpy array with all the images
	#tgs is a numpy array with the tags of the images
	imgs = np.empty((len(list(rows)),height,width, dims),dtype=np.uint8)
	tgs = np.empty((len(list(rows)),1))
		
	for row,i in zip(rows,range(len(rows))):
			
		#convert the list back to the image format
		img = row['image']
		img = img.strip('[').strip(']').split(', ')
		im = np.array(img,dtype=np.uint8) #1Dimensional array 1D.
		im = im.reshape((26,34))
		im = np.expand_dims(im, axis=2)  #expand the dimensional of data
		imgs[i] = im

		#the tag for open is 1 and for close is 0, it is similar to label encoding
		tag = row['state']
		if tag == 'open':
			tgs[i] = 1
		else:
			tgs[i] = 0
	
	#shuffle the dataset
	index = np.random.permutation(imgs.shape[0])
	imgs = imgs[index]
	tgs = tgs[index]

	#return images and their respective tags
	return imgs,tgs	

#make the convolution neural network
def makeModel():
	model = Sequential() #initlaizing neural network

	model.add(Conv2D(32, (3,3), padding = 'same', input_shape=(height,width,dims)))
	model.add(Activation('relu'))
	model.add(MaxPooling2D(pool_size=(2,2)))
	model.add(Conv2D(64, (2,2), padding= 'same'))
	model.add(Activation('relu'))
	model.add(MaxPooling2D(pool_size=(2, 2)))
	model.add(Conv2D(128, (2,2), padding='same'))
	model.add(Activation('relu'))
	model.add(MaxPooling2D(pool_size=(2, 2)))
	model.add(Dropout(0.25)) #overfitted value we have we are just making them remove

	model.add(Flatten())   #fully connected layer
	model.add(Dense(512))
	model.add(Activation('relu'))
	model.add(Dense(512))
	model.add(Activation('relu'))
	model.add(Dense(1))
	model.add(Activation('sigmoid'))  #output layer


	model.compile(optimizer=Adam(lr=0.001), loss='binary_crossentropy',metrics=['accuracy'])

	return model
#binary_crossentrpy: two categories,,,,,,,,categorical_crossentropy: more than two but categorical
#continuous target: MSE/ mean_squared_error.........activation: linear

def main():
    x ,y = readCsv('dataset.csv')
    xTrain,xtest,yTrain,ytest=train_test_split(x,y,test_size=0.1)
    print (xTrain.shape[0])
    	#scale the values of the images between 0 and 1
    xTrain = xTrain.astype('float32')
    xTrain /= 255    #pixel: 0-255
    
    model = makeModel()
    
    	#do some data augmentation
    datagen = ImageDataGenerator(
        rotation_range=10,
        width_shift_range=0.2,
        height_shift_range=0.2,
        )
    datagen.fit(xTrain)
    
    	#train the model
    model.fit_generator(datagen.flow(xTrain,yTrain,batch_size=32),
    						steps_per_epoch=len(xTrain) / 32, epochs=10)
    xtest=xtest.astype('float')
    ypred=model.predict(xtest)
    print("the predicted result by CNN is:",ypred)
    for i in range(len(ypred)):
        ypred[i]=int(ypred[i])
    from sklearn.metrics import accuracy_score
    acc=accuracy_score(ypred,ytest)
    print("the accuracy score:>",acc)
    
    model.save("filename.hdf5")
if __name__ == '__main__':
	main()
'''
0) take image from camera
1) convert it in gray scale (2100*2100)
2) find the area of interest. Haar cascade algo.
3) 400*440 pixels
4) reshape it 26*34
5) import in algo
        
Project: 
    currency images: 10 rs and 20 rs and take many images 26*34
    
'''