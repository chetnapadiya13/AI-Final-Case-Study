'''
haarcascade_frontalface_alt.xml
'''
import cv2
imagep="g1.jpg"
cascp="haarcascade_frontalface_default.xml"

facecascade=cv2.CascadeClassifier(cascp)

#READ IMAGE
image=cv2.imread(imagep)
gray=cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)

#DETECT FACE IN A IMAGE

faces=facecascade.detectMultiScale(gray,
                                   scaleFactor=1.05,
                                   minNeighbors=5,
                                   minSize=(30,30),
                                   flags=cv2.CASCADE_SCALE_IMAGE)

print("Found {} faces !".format(len(faces)))

#draw rectangle around the faces 

for (x,y,w,h) in faces:
    cv2.rectangle(image,(x,y),(x+w,y+h),(0,255,0),2)
    
cv2.imshow("faces found",image)
cv2.waitKey(0)


